def the_commons(list1,list2):
	return set([num for num in list2 if num in list1])
