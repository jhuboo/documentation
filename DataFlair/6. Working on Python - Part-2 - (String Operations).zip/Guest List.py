def guest_list(attendees):
	return [name.split(' ')[0] for name in attendees]
