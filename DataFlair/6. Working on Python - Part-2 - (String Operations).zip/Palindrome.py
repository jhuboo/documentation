def is_palindrome(val):
	return str(val)==str(val)[::-1]
