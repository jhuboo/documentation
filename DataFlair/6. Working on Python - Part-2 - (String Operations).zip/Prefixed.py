def prefixed(strings,prefix):
    return [string for string in strings if string.startswith(prefix)]
