def conflicts(list1):
	return list(zip(list1[:],list1[2:]))
