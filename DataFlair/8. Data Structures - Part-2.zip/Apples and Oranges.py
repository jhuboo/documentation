def fruits(values):
	results=dict()
	for point in values:
		results[point]=2*point[0]+3*point[1]
	return results
