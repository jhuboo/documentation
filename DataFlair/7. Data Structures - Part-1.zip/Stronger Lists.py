def stronger_list(arr):
	return [val*len(arr) for val in arr]
