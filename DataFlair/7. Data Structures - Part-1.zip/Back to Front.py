def back_to_front(string):
	return ' '.join(reversed(string.split(' ')))
