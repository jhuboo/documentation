def threes(n):
	return [item for item in range(n) if item%3==0]
