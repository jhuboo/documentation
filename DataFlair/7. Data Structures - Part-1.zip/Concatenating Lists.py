def concat(*lists):
	return [i for l in lists for i in l]
