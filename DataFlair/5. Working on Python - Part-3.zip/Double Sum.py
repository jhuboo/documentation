def double_sum(a,b):
	return (1+int(a==2*b))*(a+b)
