def not_gate(digit):
	return 1-digit
	#or return [1,0][digit]
