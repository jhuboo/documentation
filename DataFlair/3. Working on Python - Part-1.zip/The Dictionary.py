def dictionary(word):
    return ''.join(sorted(list(word)))
