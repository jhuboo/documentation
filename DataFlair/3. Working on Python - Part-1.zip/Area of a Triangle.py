def triangle(base,height):
	return int(base*height*0.5)
