def the_middle(string):
	return string[int((len(string)-1)/2)]
