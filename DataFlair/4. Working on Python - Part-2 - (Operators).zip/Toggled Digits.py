def toggle(num,pos):
	num^=(1<<pos)
	return num
