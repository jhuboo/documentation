def modern_sum(a,b):
	return 100 if (a+b>=9 and a+b<=18) else a+b

def modern_sum(a,b):
        return 100*(a+b>=9 and a+b<=18) or a+b
