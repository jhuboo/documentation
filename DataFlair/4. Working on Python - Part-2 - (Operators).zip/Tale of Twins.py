def larger_twin(num):
	return num>=int(str(num)[::-1])
