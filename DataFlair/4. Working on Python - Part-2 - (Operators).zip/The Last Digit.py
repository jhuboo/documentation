def last_digit(a,b,c):
	return str(a*b)[-1]==str(c)[-1]
